const mongoose = require("mongoose");

// Define schema
const productSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  price: {
    type: Number,
    required: true,
  },
  category: {
    type: String,
    required: true,
  },
});

// Create model
module.exports = mongoose.model("Product", productSchema);
