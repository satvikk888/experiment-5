# FS-EXP-5
This repo is for experiment 5 of full stack (CU).

## Proofs

## Experiment 1
<img src="./Assest/1.png" alt="Experiment 1">
<img src="./Assest/2.png" alt="Experiment 1">
<img src="./Assest/3.png" alt="Experiment 1">
<img src="./Assest/4.png" alt="Experiment 1">

## Experiment 2
<img src="./Assest/5.png" alt="Experiment 2">
<img src="./Assest/6.png" alt="Experiment 2">
<img src="./Assest/7.png" alt="Experiment 2">
<img src="./Assest/8.png" alt="Experiment 2">
<img src="./Assest/9.png" alt="Experiment 2">

## Experiment 3
<img src="./Assest/10.png" alt="Experiment 3">
<img src="./Assest/11.png" alt="Experiment 3">
<img src="./Assest/12.png" alt="Experiment 3">
<img src="./Assest/13.png" alt="Experiment 3">
<img src="./Assest/14.png" alt="Experiment 3">